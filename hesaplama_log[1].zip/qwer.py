import tkinter as tk
from tkinter import messagebox
import keyboard
import mouse
import threading
import re
import os
from datetime import datetime, timedelta
import time

result_window = None
keyboard_hook_id = None
mouse_hook_id = None
input_text = ""

is_active = False
slash_count = 0

last_slash_time = 0

# ===============================
# Loglama & Dosya Temizliği
# ===============================

def log_operation(input_text, result):
    formatted_result = f"{result:.2f}".replace('.', ',')
    current_time = datetime.now().strftime("%H:%M")
    with open("hesaplama_log.txt", "a", encoding="utf-8") as log_file:
        log_file.write(f"{current_time} - {input_text} = {formatted_result}\n")
    
    # Haftalık temizleme işlemi
    delete_old_logs("hesaplama_logs", days_to_keep=7)

def delete_old_logs(log_directory, days_to_keep=7):
    now = datetime.now()
    if not os.path.isdir(log_directory):
        print(f"Geçersiz dizin: {log_directory}")
        return

    for filename in os.listdir(log_directory):
        file_path = os.path.join(log_directory, filename)
        try:
            modification_time = datetime.fromtimestamp(os.path.getmtime(file_path))
            age = now - modification_time
            if age > timedelta(days=days_to_keep):
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    print(f"Silindi: {file_path} (Yaş: {age.days} gün)")
        except Exception as e:
            print(f"{file_path} işlenirken hata oluştu: {e}")

# =====================================
#  İşlem Analizi & Hesaplama
# =====================================

def calculate_and_log_steps(input_text):
    try:
        # Virgülü noktaya çevir
        input_text = input_text.replace(',', '.')
        
        # Parantez içindeki işlemleri sırayla çöz
        while '(' in input_text:
            start = input_text.rfind('(')
            end = input_text.find(')', start)
            sub_expr = input_text[start+1:end]
            
            # Bu alt işlemi hesapla
            sub_result = eval(sub_expr)
            formatted_sub_result = f"{sub_expr} = {sub_result:.2f}".replace('.', ',')
            current_time = datetime.now().strftime("%H:%M")
            with open("hesaplama_log.txt", "a", encoding="utf-8") as log_file:
                log_file.write(f"{current_time} - {sub_expr} = {sub_result:.2f}\n")
            
            # Alt sonucu ana ifadeye yerleştir
            input_text = input_text[:start] + str(sub_result) + input_text[end+1:]
        
        # Son işlemi hesapla ve logla
        result = eval(input_text)  # Eval ile işlemi çöz
        formatted_result = f"{result:.2f}".replace('.', ',')
        current_time = datetime.now().strftime("%H:%M")
        with open("hesaplama_log.txt", "a", encoding="utf-8") as log_file:
            log_file.write(f"{current_time} - {input_text} = {formatted_result}\n")
        
        return result
    
    except Exception as e:
        return f"Hesaplama hatası: {str(e)}"

# =====================================
#  GUI Pencere Yönetimi
# =====================================

def close_window(event=None):
    global result_window, keyboard_hook_id, mouse_hook_id, is_active
    if result_window and result_window.winfo_exists():
        if keyboard_hook_id is not None:
            keyboard.unhook(keyboard_hook_id)
        if mouse_hook_id is not None:
            mouse.unhook(mouse_hook_id)
        result_window.destroy()
        result_window = None
    is_active = False
    reset_keyboard_listener()

def show_result_in_gui(result):
    global result_window, keyboard_hook_id, mouse_hook_id

    # Sonuç penceresini aç
    result_window = tk.Toplevel(root)
    result_window.title("Hesaplama Sonucu")
    result_window.configure(bg="black")
    result_window.overrideredirect(True)
    result_window.attributes("-topmost", True)
    result_window.focus_force()
    result_window.protocol("WM_DELETE_WINDOW", close_window)

    screen_width = result_window.winfo_screenwidth()
    screen_height = result_window.winfo_screenheight()
    result_window.geometry(f"300x100+{int(screen_width/2 - 150)}+{int(screen_height/2 - 50)}")

    formatted_result = f"{float(result):.2f}".replace('.', ',')
    tk.Label(result_window, text=f"Sonuç: {formatted_result}", font=("Arial", 24), fg="white", bg="black").pack(expand=True, pady=5)
    tk.Label(result_window, text="Kapatmak için herhangi bir tuşa basın veya tıklayın", font=("Arial", 10), fg="#ecf0f1", bg="#2c3e50").pack(pady=5)

    keyboard.unhook_all()
    keyboard_hook_id = keyboard.hook(lambda e: close_window() if e.event_type == keyboard.KEY_DOWN else None)
    mouse_hook_id = mouse.hook(lambda e: close_window() if e.event_type == mouse.DOWN else None)

# =====================================
#  Klavye Dinleme & Tepkiler
# =====================================

def reset_keyboard_listener():
    keyboard.unhook_all()
    keyboard.on_press(on_press)

def on_press(event):
    global input_text, is_active, slash_count, last_slash_time

    current_time = time.time()
    if event.name == '/':
        if current_time - last_slash_time > 3:
            slash_count = 0
        last_slash_time = current_time
        slash_count += 1

        if slash_count == 3:
            is_active = True
            slash_count = 0
            input_text = ""
            print("Program aktif! İşlem girin:")
        elif is_active:
            input_text += '/'
        return

    if not is_active:
        return

    try:
        if event.name == ',' or event.scan_code == 83:
            input_text += '.'
        elif event.name in '0123456789+-*/.()':  # Parantezleri de işleme dahil etmek için
            input_text += event.name
        elif event.name == 'enter':
            result = calculate_and_log_steps(input_text)  # Adım adım kaydet ve hesaplaama kısımı
            print(f"Sonuç: {result}")
            if isinstance(result, (int, float)):
                log_operation(input_text, result)
                show_result_in_gui(result)  # Sonucu GUI penceresinde göster
            else:
                messagebox.showerror("Hata", result)
            input_text = ""
            is_active = False
    except AttributeError:
        pass

def listen_for_keys():
    keyboard.on_press(on_press)
    keyboard.wait()

# =====================================
# Ana Başlatıcı Fonksiyon
# =====================================

def main():
    global root, input_text, is_active, slash_count, last_slash_time
    input_text = ""
    is_active = False
    slash_count = 0
    last_slash_time = 0

    log_directory = os.path.join(os.path.expanduser("~"), "hesaplama_logs")
    os.makedirs(log_directory, exist_ok=True)
    days_to_keep = 7  # Haftalık temizlik
    delete_old_logs(log_directory, days_to_keep)

    root = tk.Tk()
    root.withdraw()  # Ana pencereyi gizle

    threading.Thread(target=listen_for_keys, daemon=True).start()
    root.mainloop()

# =====================================
# 🔁 Çalıştırıcı
# =====================================

if __name__ == "__main__":
    main()
